
Question 7 

make
./Q_7_A4 16000000 1
./Q_7_A4 16000000 2
./Q_7_A4 16000000 4
./Q_7_A4 160000000 2

---------------------------------------------------
Question 8

create file first
dd if=/dev/zero of=file_to_map.txt bs=1M count=1

make
./Q_8_A4
